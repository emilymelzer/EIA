namespace Rodelhang {

    export class DrawObject {
        xP: number;
        yP: number;
        xD: number;
        yD: number;
        colorBody: string;
        color: string;
        md: boolean;
        
        typ: string;
      

        draw(): void {

        }
        
        move(): void {

        }

        moveDown(): void {

        }

        moveUp(): void {

        }
    }
}