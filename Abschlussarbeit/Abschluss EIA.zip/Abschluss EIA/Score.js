var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Rodelhang;
(function (Rodelhang) {
    var Score = (function (_super) {
        __extends(Score, _super);
        function Score() {
            _super.apply(this, arguments);
        }
        return Score;
    }(Rodelhang.DrawObject));
    Rodelhang.Score = Score;
})(Rodelhang || (Rodelhang = {}));
//# sourceMappingURL=Score.js.map