namespace Rodelhang {

    export class Score extends DrawObject {
        }
    }