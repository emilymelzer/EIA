interface AssocStringString {
    [key: string]: string;
}

interface Highscore {
    name: string;
    score: number;
}
    