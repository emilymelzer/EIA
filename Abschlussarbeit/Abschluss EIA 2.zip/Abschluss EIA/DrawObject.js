var Rodelhang;
(function (Rodelhang) {
    var DrawObject = (function () {
        function DrawObject() {
        }
        DrawObject.prototype.draw = function () {
        };
        DrawObject.prototype.move = function () {
        };
        DrawObject.prototype.moveDown = function () {
        };
        DrawObject.prototype.moveUp = function () {
        };
        return DrawObject;
    }());
    Rodelhang.DrawObject = DrawObject;
})(Rodelhang || (Rodelhang = {}));
//# sourceMappingURL=DrawObject.js.map